//
//  CheatBotuuid.h
//  iBOT
//
//  Created by Lol on 12/11/23.
//
#import <Foundation/Foundation.h>

@interface KeychainUtility : NSObject

+ (NSString *)getPersistentUUID;

@end
